Run `make` to compile the project!
